describe('Flujo de compra en SauceDemo', () => {
    it('Debería autenticar, agregar productos al carrito y finalizar la compra', () => {
      // Visitar la página de inicio de sesión
      cy.visit("https://www.saucedemo.com/")
      
    // Autenticarse con el usuario y contraseña proporcionados
      cy.get('#user-name').type('standard_user');
      cy.get('[data-test="password"]').type('secret_sauce');
      cy.get('[data-test="login-button"]').click();
  
    // //   // Verificar que se haya iniciado sesión correctamente
     cy.url().should('include', '/inventory.html');
  
    // //   // Agregar dos productos al carrito
      cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
      cy.get('[data-test="add-to-cart-sauce-labs-bike-light"]').click();
  
    // //   // Visualizar el carrito
    cy.get('.shopping_cart_link').click();
    cy.url().should('include', '/cart.html');
  
    // //   // Proceder a la compra
      cy.get('[data-test="checkout"]').click();
      cy.url().should('include', '/checkout-step-one.html');
  
    // //   // Completar el formulario de compra
      cy.get('[data-test="firstName"]').type('John');
      cy.get('[data-test="lastName"]').type('Doe');
      cy.get('[data-test="postalCode"]').type('12345');
      cy.get('[data-test="continue"]').click();
  
    // //   // Finalizar la compra
      cy.get('[data-test="finish"]').click();
  
    // //   // Verificar la confirmación de la compra
      cy.get('.complete-header').should('have.text', 'Thank you for your order!');
     });
  });
