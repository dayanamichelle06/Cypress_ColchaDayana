describe('Pruebas de APIs de DemoBlaze', () => {
    const baseUrl = 'https://api.demoblaze.com';
    const newUser = {
      username: 'DayanaColcha4',
      password: 'Test1234'
    };
    const existingUser = {
      username: 'existing_user',
      password: 'correct_password'
    };
    const incorrectUser = {
      username: 'existing_user',
      password: 'incorrect_password'
    };
  
    it('Crear un nuevo usuario en signup', () => {
      cy.request('POST', ${baseUrl}/signup, newUser)
        .then((response) => {
          expect(response.status).to.eq(200);
          expect(response.body).to.have.property('status', 'OK');
        });
    });
  
    it('Intentar crear un usuario ya existente', () => {
      cy.request({
        method: 'POST',
        url: ${baseUrl}/signup,
        body: existingUser,
        failOnStatusCode: false
      }).then((response) => {
        expect(response.status).to.eq(400);
        expect(response.body).to.have.property('status', 'Fail');
        expect(response.body).to.have.property('message', 'This user already exists');
      });
    });
  
    it('Usuario y password correcto en login', () => {
      cy.request('POST', ${baseUrl}/login, existingUser)
        .then((response) => {
          expect(response.status).to.eq(200);
          expect(response.body).to.have.property('status', 'OK');
          expect(response.body).to.have.property('token');
        });
    });
  
    it('Usuario y password incorrecto en login', () => {
      cy.request({
        method: 'POST',
        url: ${baseUrl}/login,
        body: incorrectUser,
        failOnStatusCode: false
      }).then((response) => {
        expect(response.status).to.eq(400);
        expect(response.body).to.have.property('status', 'Fail');
        expect(response.body).to.have.property('message', 'Invalid username or password');
      });
    });
  });
